from django.apps import AppConfig


class SuirConfig(AppConfig):
    name = 'suir'
    default_auto_field = 'django.db.models.BigAutoField'
