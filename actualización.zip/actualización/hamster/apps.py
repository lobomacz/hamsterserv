from django.apps import AppConfig


class HamsterConfig(AppConfig):
    name = 'hamster'
    default_auto_field = 'django.db.models.BigAutoField'
